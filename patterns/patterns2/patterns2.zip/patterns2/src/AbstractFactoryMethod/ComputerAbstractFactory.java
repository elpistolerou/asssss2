package AbstractFactoryMethod;

public interface ComputerAbstractFactory { // интерфейс для создания компа
    public Computer createComputer(); // возвращает обьект класса компьютер
}